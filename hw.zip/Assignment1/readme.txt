Readme

 - Upload the notebook to google colab
 - place the 'iris_data.txt' in the same directory as the .ipynb file
 - Then run all the cells 